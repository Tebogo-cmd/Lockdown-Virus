Lockdown Virus(Prank)  V1 - For Windows
------------------------------------------------------------------------------------------------+
LEGAL stuff :											|
- The lockdown virus was designed as a prank and should be used as such on willing victims.     |
- Wherever this code runs, you will need the "victims" consent.					|
- I will not be held liable to any damage caused to your/"victims" computer system.		|
- It is advised that you stop the program after +-2mins of running on a machine.		|
												|
DATE : 03/21/2022										|
												|
------------------------------------------------------------------------------------------------+


The zip file / folder contains :
1) main.bat
2) VIRUSREMOVE.bat
3) Lockdown-Virus FOLDER which contains :
   - empty.mp3
   -notepad..exe
   -Scanner.bat
   -start.vbs
   -tcut.bat
   -windowsdefender.exe



How to activate it on the "victims" windows machine:
1) Open the L-Virus directory 
2) click/run  the "main.bat" file
3) The "Virus" should be in the system
4) Whenever the user signsOUT then signsIN of the computer, the virus will do some annoying stuff
5) AN annoying sound will be played then a cmd window requesting a PIN will pop up every +-2secs
6) The PIN is: abAB
7) The PIN is: abAB
8) The PIN is: abAB

How to Remove the Virus
1) make sure the virus is not running, if it is Enter the PIN on the pop up cmd window/s 
2) Open the L-Virus directory
3) click/run the VIRUSREMOVE.bat file
4) That should delete all Lockdown Virus files excluding the directory,000READ_ME.txt,main.bat and VIRUSREMOVE.bat
5) Do not include your personal files in those directories because they might get deleted

Tested Devices :
-The Virus was tested on Two Windows 10 machines
-It worked perfectly

Message From me:
-Please Look at all the code, so that you understand how it works. (Start at "start.vbs")
-EveryThing is basic, so a youtube/Google search should be able to help you.
-As you have already realized, the Prank is basically batch scripts moving things around.
-the "start.vbs" script is used to run the batch script in the background.
-the "tcut.bat" is placed in the user startUp apps to start "start.vbs"
-The very basic password module("windowsdefender.exe") was written in C.
-It basically shutsdown cmd to stop the batch scripts.Therefore you can write your own password module.
-You can modify the files as you see fit, just make sure you know what you are doing.
- HAVE FUN!!!!

TroubleShoot
1)Make sure you unziped the L-Virus in a directory like Desktop,Downloads,music,Documents..etc
2)Make sure the file structure is exactly the same as downloaded
3)Do not remove files(Use The VirusRemover) or change file names
4)If for some reason you forgot the PIN :
-Open a new CMD window
-Then Type this command : "Taskkill /f /im cmd.exe"
